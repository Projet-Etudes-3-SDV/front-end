import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
  standalone: false
})
export class RegisterPage {
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  password: string = '';

  constructor(
    private apiService: ApiService,
    private router: Router,
    private toastController: ToastController
  ) {}

  async register() {
    try {
      const response = await this.apiService.createUser({
        firstName: this.firstName,
        lastName: this.lastName,
        email: this.email,
        password: this.password
      });
      if (response.data) {
        this.presentToast('Inscription réussie. Veuillez vérifier votre email pour valider votre compte.', 'success');
        this.router.navigate(['/login']);
      }
    } catch (error: any) {
      console.log(error)
      if (error.response.data.code === 'EMAIL_ALREADY_IN_USE') {
        this.presentToast('Email déjà utilisé. Veuillez utiliser un autre email.', 'danger');
      } else {
        this.presentToast('Échec de l\'inscription. Veuillez réessayer.', 'danger');
      }
    }
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      color,
      duration: 4000,
      position: 'top'
    });
    toast.present();
  }
}
